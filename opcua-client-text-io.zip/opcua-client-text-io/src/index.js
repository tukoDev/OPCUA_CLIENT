"use strict";

const fs = require("fs");
const path = require("path");
const { OPCUAClient, MessageSecurityMode, SecurityPolicy, AttributeIds, TimestampsToReturn, ClientMonitoredItem } = require("node-opcua");

function parseConfig(filePath) {
  const data = fs.readFileSync(filePath, "utf-8");
  const result = {};
  data.split(/\r?\n/).forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith(";")) return;
    const eq = trimmed.indexOf("=");
    if (eq === -1) return;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    result[key] = value;
  });
  return result;
}

function mapSecurityMode(mode) {
  const m = String(mode || "None").toLowerCase();
  if (m === "sign") return MessageSecurityMode.Sign;
  if (m === "signandencrypt" || m === "signandencryption") return MessageSecurityMode.SignAndEncrypt;
  return MessageSecurityMode.None;
}

function mapSecurityPolicy(policy) {
  const p = String(policy || "None").toLowerCase();
  if (p === "none") return SecurityPolicy.None;
  if (p.includes("basic128")) return SecurityPolicy.Basic128Rsa15;
  if (p.includes("basic256sha256")) return SecurityPolicy.Basic256Sha256;
  if (p.includes("basic256")) return SecurityPolicy.Basic256;
  if (p.includes("aes128")) return SecurityPolicy.Aes128_Sha256_RsaOaep;
  if (p.includes("aes256")) return SecurityPolicy.Aes256_Sha256_RsaPss;
  return SecurityPolicy.None;
}

function valueToString(val) {
  if (val === undefined) return "";
  if (val === null) return "null";
  if (Buffer.isBuffer(val)) return "0x" + val.toString("hex");
  if (Array.isArray(val)) return JSON.stringify(val);
  switch (typeof val) {
    case "object":
      try { return JSON.stringify(val); } catch { return String(val); }
    case "string":
      return val.replace(/\n/g, " " );
    default:
      return String(val);
  }
}

async function cleanup(session, client, stream) {
  try { await session.close(); } catch {}
  try { await client.disconnect(); } catch {}
  try { stream.end(); } catch {}
}

async function main() {
  // Environment variable'dan machine tipini al
  const machineType = process.env.MACHINE_TYPE || "default";
  
  // Machine tipine göre config dosyasını belirle
  let configFileName = "config.txt"; // default
  if (machineType === "machine1") {
    configFileName = "machine1.txt";
  } else if (machineType === "machine2") {
    configFileName = "machine2.txt";
  }
  
  const configPath = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(process.cwd(), "config", configFileName);
  const cfg = parseConfig(configPath);
  const baseDir = path.dirname(configPath);
  const outputPath = cfg.output && path.isAbsolute(cfg.output) ? cfg.output : path.resolve(baseDir, cfg.output || "output.txt");
  const writeStream = fs.createWriteStream(outputPath, { flags: "a" });
  const logToFile = (line) => {
    console.log(line); // Docker logs için console.log
    writeStream.write(line + "\n"); // Dosyaya da yazmaya devam et
  };

  const endpointUrl = cfg.endpointUrl || "opc.tcp://40.69.57.27:49380";
  const client = OPCUAClient.create({
    applicationName: "TextIOClient",
    securityMode: mapSecurityMode(cfg.securityMode),
    securityPolicy: mapSecurityPolicy(cfg.securityPolicy),
    endpointMustExist: false,
    connectionStrategy: { maxRetry: 3, initialDelay: 2000, maxDelay: 10000 }
  });

  await client.connect(endpointUrl);
  const session = cfg.userName
    ? await client.createSession({ userName: cfg.userName, password: cfg.password || "" })
    : await client.createSession();

  const nodes = (cfg.nodes || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (nodes.length === 0) {
    console.error("No nodes specified in config. Set nodes=ns=0;i=2258,ns=0;i=2260");
    await session.close();
    await client.disconnect();
    process.exit(1);
  }

  const mode = (cfg.mode || "monitor").toLowerCase();
  const intervalMs = parseInt(cfg.intervalMs || "1000", 10);

  if (mode === "read") {
    logToFile(`# READ mode [${machineType}] ${new Date().toISOString()} endpoint=${endpointUrl} intervalMs=${intervalMs}`);
    const timer = setInterval(async () => {
      try {
        const nodesToRead = nodes.map((nodeId) => ({ nodeId, attributeId: AttributeIds.Value }));
        const dataValues = await session.read(nodesToRead, 0);
        dataValues.forEach((dv, i) => {
          const nodeId = nodes[i];
          const value = valueToString(dv.value && dv.value.value);
          const status = dv.statusCode && dv.statusCode.toString();
          const srcTs = dv.sourceTimestamp ? dv.sourceTimestamp.toISOString() : "";
          const srvTs = dv.serverTimestamp ? dv.serverTimestamp.toISOString() : "";
          logToFile(`${new Date().toISOString()} | ${nodeId} | ${value} | ${status} | src=${srcTs} | srv=${srvTs}`);
        });
      } catch (err) {
        console.error("Read error:", err.message || err);
      }
    }, intervalMs);

    process.on("SIGINT", async () => {
      clearInterval(timer);
      await cleanup(session, client, writeStream);
      process.exit(0);
    });
  } else {
    logToFile(`# MONITOR mode [${machineType}] ${new Date().toISOString()} endpoint=${endpointUrl} intervalMs=${intervalMs}`);
    const subscription = await session.createSubscription2({
      requestedPublishingInterval: intervalMs,
      requestedLifetimeCount: 100,
      requestedMaxKeepAliveCount: 10,
      maxNotificationsPerPublish: 100,
      publishingEnabled: true,
      priority: 10
    });

    subscription.on("terminated", () => {
      console.log("Subscription terminated");
    });

    for (const nodeId of nodes) {
      const item = await ClientMonitoredItem.create(
        subscription,
        { nodeId, attributeId: AttributeIds.Value },
        { samplingInterval: intervalMs, discardOldest: true, queueSize: 100 },
        TimestampsToReturn.Both
      );
      item.on("changed", (dv) => {
        const value = valueToString(dv.value && dv.value.value);
        const status = dv.statusCode && dv.statusCode.toString();
        const srcTs = dv.sourceTimestamp ? dv.sourceTimestamp.toISOString() : "";
        const srvTs = dv.serverTimestamp ? dv.serverTimestamp.toISOString() : "";
        logToFile(`${new Date().toISOString()} | ${nodeId} | ${value} | ${status} | src=${srcTs} | srv=${srvTs}`);
      });
      item.on("err", (errMessage) => {
        console.error("MonitoredItem error:", errMessage);
      });
    }

    process.on("SIGINT", async () => {
      await subscription.terminate();
      await cleanup(session, client, writeStream);
      process.exit(0);
    });
  }
}

main().catch(async (err) => {
  console.error("Fatal error:", err.message || err);
  process.exit(1);
});
